using UnityEngine;
using UnityEngine.AI;

public class GuardScanBehavior : StateMachineBehaviour
{
    NavMeshAgent _guardAgent;
    GuardMovement _guardMovement;
    bool scanning;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _guardMovement = animator.gameObject.GetComponent<GuardMovement>();
        scanning = false;
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (scanning)   //Si ya est� escaneando la zona, impida que se vuelva a llamar a la funci�n
        {
            return;
        }

        _guardMovement.ScanTheZoneLookingForThief();    //Escanea la zona en busca del ladr�n
        scanning = true;
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
