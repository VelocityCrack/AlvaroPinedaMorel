using UnityEngine;
using UnityEngine.AI;

public class GuardSeekBehavior : StateMachineBehaviour
{
    NavMeshAgent _guardAgent;
    GuardMovement _guardMovement;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _guardAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        _guardMovement = animator.gameObject.GetComponent<GuardMovement>();
        _guardMovement.GoToThiefLastSeenPosition();     //Va a la �tlima posici�n donde ha visto al ladr�n
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (_guardMovement.LookForThiefRaycast())       //Comprueba si ve al ladr�n
        {
            animator.SetTrigger("Pursue");
        }

        if (!_guardAgent.pathPending && _guardAgent.remainingDistance < 0.5f)       //Comprueba cu�ndo llega a la �ltima posici�n donde se ha visto al ladr�n
        {
            animator.SetTrigger("Scan");
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
