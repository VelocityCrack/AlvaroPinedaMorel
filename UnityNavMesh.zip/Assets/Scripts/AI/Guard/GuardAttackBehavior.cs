using UnityEngine;

public class GuardAttackBehavior : StateMachineBehaviour
{
    GuardMovement _guardMovement;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _guardMovement = animator.gameObject.GetComponent<GuardMovement>();
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (_guardMovement.CheckForAttack())        //Compureba si est� a rango de atacar
        {
            Debug.Log("Attack");
            _guardMovement.AttackThief();
            animator.SetTrigger("Patrol");
        }

        if (_guardMovement.CheckForPursue())        //Comprueba si el ladr�n se ha alejado lo suficiente como para pasar a perseguirlo
        {
            animator.SetTrigger("Pursue");
        }

        if (!_guardMovement.LookForThiefTargetedRaycast())      //Compureba que se siga teniendo en rango de visi�n al ladr�n
        {
            animator.SetTrigger("Seek");
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
