using UnityEngine;
using UnityEngine.AI;

public class GuardPursueBehavior : StateMachineBehaviour
{
    NavMeshAgent _guardAgent;
    GuardMovement _guardMovement;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _guardAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        _guardMovement = animator.gameObject.GetComponent<GuardMovement>();
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (_guardMovement.CheckForAttack())        //Comprubea si puede cambiar a atacar
        {
            animator.SetTrigger("Attack");
        }

        if (!_guardMovement.LookForThiefTargetedRaycast())      //Compureba si sigue viendo al ladr�n y lo tiene a rango
        {
            if (AIDirector.Instance.alarmTriggered)
            {
                animator.SetTrigger("Alarm");
            }
            else
            {
                animator.SetTrigger("Seek");
            }
        }

        _guardMovement.GoToThiefLastSeenPosition();     //Va a la �ltima posici�n donde ha visto al ladr�n
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
