using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class GuardMovement : Movement
{
    private Transform lastPatrolPoint;
    private Vector3 thiefLastSeenPosition;
    public GameObject thiefSeenGO;
    private Animator _animator;

    protected override void Start()
    {
        base.Start();
        _animator = GetComponent<Animator>();
    }

    public bool LookForThiefRaycast()   //Tira un raycast para comprobar si ve al ladr�n
    {
        RaycastHit hit;

        Debug.DrawRay(_realPosition, 10 * transform.forward, Color.red);

        if (Physics.Raycast(_realPosition, 10 * transform.forward, out hit))
        {
            if (hit.collider.GetComponent<ThiefMovement>() != null)
            {
                thiefSeenGO = hit.transform.gameObject;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
        
    }

    public bool LookForThiefTargetedRaycast()       //Tira un raycast en direcci�n al ladr�n ya visto para comprobar si le ve (puede haber girado una esquina) y c�mo de lejos est�
    {
        RaycastHit hit;

        Debug.DrawRay(_realPosition, (thiefSeenGO.GetComponent<ThiefMovement>()._realPosition - _realPosition).normalized * 10, Color.red);

        if (Physics.Raycast(_realPosition, (thiefSeenGO.GetComponent<ThiefMovement>()._realPosition - _realPosition).normalized, out hit, 10))
        {
            if (hit.collider.gameObject.GetComponent<ThiefMovement>() != null)
            {
                thiefLastSeenPosition = thiefSeenGO.GetComponent<ThiefMovement>()._realPosition;
                return true;
            }
            else
            {
                return false;
            }
        } 
        else 
        { 
            return false; 
        }
        
    }

    public bool CheckForAttack()        //Comprueba la distacia a la que est� del ladr�n para poder atacarle
    {
        if (Vector3.Distance(_realPosition, thiefSeenGO.GetComponent<ThiefMovement>()._realPosition) <= 1.5f)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void AttackThief()   //Ataca al ladr�n y lo deja KO
    {
        thiefSeenGO.GetComponent<ThiefMovement>().KO();
        print("Thief KO");
    }

    public bool CheckForPursue()        //Comprueba si el ladr�n se ha alejado lo suficiente para cambiar de atacar a perseguir
    {
        if (Vector3.Distance(_realPosition, thiefSeenGO.GetComponent<ThiefMovement>()._realPosition) >= 2)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void GoToThiefLastSeenPosition()     //Va a la �ltima posici�n donde ha visto al ladr�n
    {
        GoToPosition(thiefLastSeenPosition);
    }

    public void ScanTheZoneLookingForThief()        //Escanea la zona dando una vuelta de 360� en busca del ladr�n
    {
        StartCoroutine(IScaneTheZoneLookingForThief());
    }

    private IEnumerator IScaneTheZoneLookingForThief()
    {
        for (int i = 0; i < 72; i++) 
        {
            transform.Rotate(5 * Vector3.up);
            
            if (LookForThiefRaycast())
            {
                _animator.SetTrigger("Pursue");
                StopAllCoroutines();
            }

            yield return new WaitForSeconds(0.04f);
        }

        _animator.SetTrigger("Patrol");
    }

    public void GoToThiefLastSeenPositionAlarm()
    {
        base.GoToPosition(AIDirector.Instance.lastSpotedThiefPos);
    }
}
