using UnityEngine;
using UnityEngine.AI;

public abstract class Movement : MonoBehaviour
{
    public Transform[] points;
    public int destPoint = 0;
    protected NavMeshAgent agent;
    public float speed;  
    public Vector3 _realPosition;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    protected virtual void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        destPoint = Random.Range(0, points.Length);
        agent.speed = speed;
    }

    protected void GoToNextPoint(Transform point)       //Va al siguiente punto de patrulla (datos, patrulla o croissant, seg�n el agente)
    {
        if (points.Length == 0)
            return;

        // Set the agent to go to the currently selected destination.
        agent.destination = point.position;
    }

    protected virtual void Update()     //Actualiza la posici�n real del personaje, que en todos en la cabeza (para temas de raycast)
    {
        _realPosition = new Vector3(transform.position.x, transform.position.y + 1.5f, transform.position.z);
    }

    protected void GoToPosition(Vector3 pos)        //Va a una cierta posici�n
    {
        agent.destination = pos;
    }

    public void GoToNextPoint()     //M�todo que sirve para que se llame sin tener que pasar par�metros (en ciertas corrutinas pasa la mismo ya que se necesita un intermediario con los StatesMachines)
    {
        GoToNextPoint(points[destPoint]);
    }
}
