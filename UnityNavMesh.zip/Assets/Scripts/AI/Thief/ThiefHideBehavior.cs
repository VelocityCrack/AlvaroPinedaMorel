using UnityEngine;
using UnityEngine.AI;

public class ThiefHideBehavior : StateMachineBehaviour
{
    NavMeshAgent _thiefAgent;
    ThiefMovement _thiefMovement;
    bool _waitHiding;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _thiefMovement = animator.gameObject.GetComponent<ThiefMovement>();
        _thiefAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        _thiefMovement.GoToNearestDuct();
        _waitHiding = false;
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
   override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
   {
        if (_thiefMovement.waiting)     //Espera escondido
        {
            return;
        }

        if (!_thiefAgent.pathPending && _thiefAgent.remainingDistance < 0.3f)       //Cuando llega al escondite, espera
        {
            if (_waitHiding)
            {
                _thiefMovement.ReturnToSearch();
                _waitHiding = false;
            }
            else
            {
                _thiefMovement.WaitForSeconds(5);
                _waitHiding = true;
            }
        }
   }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
