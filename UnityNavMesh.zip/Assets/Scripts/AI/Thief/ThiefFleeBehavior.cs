using UnityEngine;
using UnityEngine.AI;

public class ThiefFleeBehavior : StateMachineBehaviour
{
    NavMeshAgent _thiefAgent;
    ThiefMovement _thiefMovement;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _thiefMovement = animator.gameObject.GetComponent<ThiefMovement>();
        _thiefAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        _thiefMovement.FleeFromGuard();
        _thiefAgent.autoBraking = false;
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (!_thiefAgent.pathPending && _thiefAgent.remainingDistance < 0.5f)       //Huye del guardia yendo a puntos alejados concatenados
        {
            Debug.Log("Flee from Guard");
            _thiefMovement.FleeFromGuard();
        }

        if (!_thiefMovement.LookForGuardSphereOverap())     //Comprueba si sigue a rango del guardia
        {
            if (AIDirector.Instance.alarmTriggered)
            {
                animator.SetTrigger("Alarm");
            }
            else 
            {
                _thiefMovement.ReturnToSearch();
            }   
        }

        _thiefMovement.PushObjects();       //Empuja los props por el camino
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _thiefAgent.autoBraking = true;
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
