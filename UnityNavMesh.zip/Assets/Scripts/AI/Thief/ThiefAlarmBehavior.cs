using UnityEngine;
using UnityEngine.AI;

public class ThiefAlarmBehavior : StateMachineBehaviour
{
    NavMeshAgent _thiefAgent;
    ThiefMovement _thiefMovement;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _thiefMovement = animator.gameObject.GetComponent<ThiefMovement>();
        _thiefAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        _thiefMovement.GoToSafeSpot();
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (_thiefMovement.LookForGuardRaycast())       //Comprueba si ve al guardia
        {
            animator.SetTrigger("Flee");        //Si le ve, huye.
        }

        if (!_thiefAgent.pathPending && _thiefAgent.remainingDistance < 0.3f && !AIDirector.Instance.alarmTriggered)       //Cuando llega al escondite, espera. Cuando se apague la alarma vuelve a la b�squeda.
        {
            _thiefMovement.ReturnToSearch();
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
