using UnityEngine;
using UnityEngine.AI;

public class ThiefSearchBehavior : StateMachineBehaviour
{
    NavMeshAgent _thiefAgent;
    ThiefMovement _thiefMovement;
    bool _waitBetweenPointsDone;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _thiefMovement = animator.gameObject.GetComponent<ThiefMovement>();
        _thiefAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        if (_thiefMovement.points == null)
        {
            _thiefMovement.points = AIDirector.Instance.GetPatrolRute(6);
        }
        _thiefMovement.GoToNextPoint();
        _waitBetweenPointsDone = false;
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (_thiefMovement.LookForGuardRaycast())       //Comprueba si ve al guardia
        {
            animator.SetTrigger("Flee");
        }

        if (_thiefMovement.LookForWorker())     //Comprueba si ve al trabajador
        {
            animator.SetTrigger("Hide");
        }

        if (_thiefMovement.waiting)     //Impide que se mueva mientras coge los datos
        {
            return;
        }

        if (!_thiefAgent.pathPending && _thiefAgent.remainingDistance < 0.3f)       //Comprueba si ha llegado a una ubicaci�n de datos. Cuando los ha cogido, pasa la siguiente.
        {
            if (_waitBetweenPointsDone)
            {
                _thiefMovement.DataRobbed();

                if (_thiefMovement.destPoint == _thiefMovement.points.Length - 1)
                {
                    _thiefMovement.points = AIDirector.Instance.GetPatrolRute(6);
                    _thiefMovement.destPoint = 0;
                }
                else
                {
                    _thiefMovement.destPoint++;
                }

                _thiefMovement.GoToNextPoint(); 
                _waitBetweenPointsDone = false;
            }
            else
            {
                _thiefMovement.WaitForSeconds(4f);
                _waitBetweenPointsDone = true;
            }
        }    
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
        
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
