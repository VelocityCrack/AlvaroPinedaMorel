using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;


public class ThiefMovement : Movement
{
    public bool waiting = false;
    public Transform[] ductsTransform;
    Animator _animator;
    GameObject _targetGuardGO;
    Collider[] _colliders = new Collider[50];
    [SerializeField] private int numDataRobbed; public void DataRobbed() => numDataRobbed++;

    protected override void Start()
    {
        base.Start();
        numDataRobbed = 0;
        _animator = GetComponent<Animator>();
    }

    protected override void Update()        //Comprueba si est� en la zona de mantenimiento y, si est�, le reduce la velocidad a la mitad
    {
        base.Update();

        bool isHitingANavMesh = NavMesh.SamplePosition(transform.position, out NavMeshHit hit, 2f, NavMesh.AllAreas);

        if (isHitingANavMesh && (hit.mask & 1 << NavMesh.GetAreaFromName("Maintenance")) != 0)
        {
            agent.speed = speed / 2;
        }
        else
        {
            agent.speed = speed;
        }
    }
    private void OnEnable()
    {
        AIDirector.Instance.AlarmDetectionEventHandler += AlarmActivated;
    }

    private void OnDisable()
    {
        AIDirector.Instance.AlarmDetectionEventHandler -= AlarmActivated;
    }

    private void AlarmActivated()
    {
        _animator.SetTrigger("Alarm");
    }

    public bool LookForWorker()         //Comprueba si ve un trabajador
    {
        RaycastHit hit;
        Debug.DrawRay(_realPosition, 10 * transform.forward, Color.red);

        if (Physics.Raycast(_realPosition, transform.forward, out hit, 10))
        {
            if (hit.collider.gameObject.GetComponent<WorkerMovement>() != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else 
        {
            return false;        
        }
        
    }

    public bool LookForGuardRaycast()       //Comprueba si ve un guardia
    {
        RaycastHit hit;
        Debug.DrawRay(_realPosition, 10 * transform.forward, Color.red);

        if (Physics.Raycast(_realPosition, transform.forward, out hit, 10))
        {
            if (hit.collider.gameObject.GetComponent<GuardMovement>() != null)
            {
                print("Guard founded");
                _targetGuardGO = hit.collider.gameObject;
                return true;
            }
            else
            {
                return false;
            }
        }
        else 
        {
            return false;
        }
    }

    public bool LookForGuardSphereOverap()      //Comprueba si el guardia que le est� persiguiendo sigue a rango
    {
        int count = 0;

        Array.Clear(_colliders, 0, _colliders.Length);

        Physics.OverlapSphereNonAlloc(_realPosition, 10, _colliders);

        foreach (var collider in _colliders) 
        {
            if (collider != null)
            {
                if (collider.gameObject.GetComponent<GuardMovement>() != null)
                {
                    count++;
                }
            }
        }

        if (count != 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void PushObjects()       //Empuja los props que tiene a 1 metro
    {
        Array.Clear(_colliders, 0, _colliders.Length);

        Physics.OverlapSphereNonAlloc(transform.position, 1, _colliders);

        foreach (var collider in _colliders)
        {
            if (collider != null) 
            {
                if (collider.gameObject.GetComponent<Rigidbody>() != null && collider.gameObject.GetComponent<WorkerMovement>() == null && collider.gameObject.GetComponent<GuardMovement>() == null && collider.gameObject.GetComponent<ThiefMovement>() == null)
                {
                    Vector3 forceDir = transform.position + (collider.transform.position - transform.position);
                    collider.gameObject.GetComponent<Rigidbody>().AddForce(forceDir.normalized * 15, ForceMode.Impulse);
                    print(collider.name);
                }
            }

        }
    }

    private Transform FindNearestDuct()            //Encuentra el conducto de ventilaci�n m�s cercano
    {
        Transform nearestDuct = ductsTransform[0];
        float distanceToNearestDuct = Vector3.Distance(nearestDuct.position, transform.position);

        for (int i = 1; i < ductsTransform.Length; i++)
        {
            if (Vector3.Distance(ductsTransform[i].position, transform.position) < distanceToNearestDuct)
            {
                nearestDuct = ductsTransform[i];
                distanceToNearestDuct = Vector3.Distance(nearestDuct.position, transform.position);
            }
        }

        return nearestDuct;
    }

    public void GoToNearestDuct()       //Va al conducto de ventilaci�n m�s cercano
    {
        GoToPosition(FindNearestDuct().position);
    }

    private Vector3 FindRouteToFlee(Vector3 dirToFlee)      //Busca una posici�n v�lida hacia donde huir del guardia. 1� En direcci�n de huida del guardia  2� Idem a 30�  3� Idem pero a -30�  4� A la izquierda del agente  5� A la derecha del agente
    {
        bool validPointFound = true;
        Vector3 importantAxis;

        if (dirToFlee.x >= dirToFlee.z)
        {
            importantAxis = Vector3.right;
        } else
        {
            importantAxis = Vector3.forward;
        }

        if (!NavMesh.SamplePosition(dirToFlee, out NavMeshHit hit, 2, NavMesh.AllAreas))    // 1� En direcci�n de huida del guardia
        {
            print("2");
            dirToFlee += 2.5f * importantAxis;
            if (!NavMesh.SamplePosition(dirToFlee, out hit, 2, NavMesh.AllAreas))       // 2� Idem a 30�
            {
                print("3");
                dirToFlee -= 5f * importantAxis;
                if (!NavMesh.SamplePosition(dirToFlee, out hit, 2, NavMesh.AllAreas))       // 3� Idem pero a -30�
                {
                    validPointFound = false;
                }
            }
        }

        if (!validPointFound)   //Mirar a izquierda y derecha
        {
            dirToFlee = new Vector3(transform.right.x, transform.right.y + 2.5f, transform.right.z).normalized * 5;
            if (NavMesh.SamplePosition(dirToFlee, out hit, 2, NavMesh.AllAreas))        // 4� A la izquierda del agente
            {
                print("4");
                validPointFound = true;
            }
            else
            {
                print("5");
                dirToFlee = new Vector3(-transform.right.x, transform.right.y + 2.5f, -transform.right.z).normalized * 5;
                if (NavMesh.SamplePosition(dirToFlee, out hit, 2, NavMesh.AllAreas))        //5� A la derecha del agente
                {
                    validPointFound = true;
                }
            }
        }
        Debug.DrawLine(_realPosition, dirToFlee, Color.magenta);
        Debug.Log(dirToFlee);

        if (validPointFound)
        {
            return dirToFlee;
        }
        else
        {
            return Vector3.zero;
        }
       
    }

    public void FleeFromGuard()     //Huye del guardia con posiciones alejadas del mismo
    {
        Vector3 dirToFlee = _realPosition + 5 * (Vector3.Normalize(_realPosition - _targetGuardGO.GetComponent<GuardMovement>().transform.position));
        dirToFlee.y = _realPosition.y;
        print("DirFleeInit: " + dirToFlee);

        GoToPosition(FindRouteToFlee(dirToFlee));
    }

    public void KO()        //Deja KO al ladr�n
    {
        print("Thief Dead");
        _animator.SetBool("KO", true);
    }

    public void ReturnToSearch()        //Vuelve a la b�squeda de cosas (datos, supongo)
    {
        _animator.SetTrigger("Search");
    }

    public void GoToSafeSpot()
    {
        GoToPosition(AIDirector.Instance.GetClosestSafePoint(_realPosition).position);
    }

    public void WaitForSeconds(float timeToWait)        //Espera cierto tiempo
    {
        StartCoroutine(IWaitSeconds(timeToWait));
    }

    private IEnumerator IWaitSeconds(float timeToWait)      //Idem
    {
        waiting = true;
        yield return new WaitForSeconds(timeToWait);
        waiting = false;
    }
}
