using UnityEngine;

public class AIDirector : Singleton<AIDirector>
{
    public delegate void AlarmDetectionDelegate();
    public AlarmDetectionDelegate AlarmDetectionEventHandler;

    public Transform[] alarmPoints;
    public Transform[] character;        //Incluye todos los puntos de patrulla 
    public Transform[] safePoints;

    public bool alarmTriggered;
    public Vector3 lastSpotedThiefPos;

    [SerializeField] private int numPatrolPointsAssigned;       //Conteo de cu�ntos puntos de patrulla ha asignado
    [SerializeField] private int numAgents;

    private void OnEnable()
    {
        AIDirector.Instance.AlarmDetectionEventHandler += AlarmActivated;
    }

    private void OnDisable()
    {
        AIDirector.Instance.AlarmDetectionEventHandler -= AlarmActivated;
    }

    private void AlarmActivated()
    {
        print("Alarm activated");
        alarmTriggered = true;
    }

    public void AlarmDisabled()
    {
        print("Alarm disabled");
        alarmTriggered = false;
    }

    public void ThiefSpoted(Vector3 thiefPos)
    {
        lastSpotedThiefPos = thiefPos;
    }

    private void Start()
    {
        GetAllAgents();
        GetAllPatrolPointsInScene();
        GetAllAlarmPointsInScene();
        GetAllSafePointsInScene();
    }

    private void GetAllAgents()     //Encuentra el n�mero de agentes en la escena. 
    {
        GameObject charactersParent = GameObject.Find("Characters");

        numAgents = charactersParent.transform.childCount;
        print("Number of agents: " + numAgents);
    }

    #region Register Points from Scene

    private void GetAllPatrolPointsInScene()
    {
        GameObject waypointParent = GameObject.Find("Waypoints");
        character = new Transform[waypointParent.transform.childCount];

        for (int i = 0; i < character.Length; i++)
        {
            character[i] = waypointParent.transform.GetChild(i).transform;
        }
    }

    private void GetAllAlarmPointsInScene()
    {
        GameObject alarmWaypointParent = GameObject.Find("Alarm Waypoints");
        alarmPoints = new Transform[alarmWaypointParent.transform.childCount];

        for (int i = 0; i < alarmPoints.Length; i++)
        {
            alarmPoints[i] = alarmWaypointParent.transform.GetChild(i).transform;
        }
    }

    private void GetAllSafePointsInScene()
    {
        GameObject safeWaypointParent = GameObject.Find("Safe Waypoints");
        safePoints = new Transform[safeWaypointParent.transform.childCount];

        for (int i = 0; i < safePoints.Length; i++)
        {
            safePoints[i] = safeWaypointParent.transform.GetChild(i).transform;
        }
    }
    #endregion

    #region Give Points To Agents
    public Transform GetClosestAlarmPoint(Vector3 workerPos)
    {
        Transform nearestAlarm = alarmPoints[0];
        float distanceToNearestAlarm = Vector3.Distance(nearestAlarm.position, workerPos);

        for (int i = 1; i < alarmPoints.Length; i++)
        {
            if (Vector3.Distance(alarmPoints[i].position, workerPos) < distanceToNearestAlarm)
            {
                nearestAlarm = alarmPoints[i];
                distanceToNearestAlarm = Vector3.Distance(nearestAlarm.position, workerPos);
            }
        }

        return nearestAlarm;
    }

    public Transform GetClosestSafePoint(Vector3 thiefPos)
    {
        Transform nearestHidingSpot = safePoints[0];
        float distanceToNearestHidingSpot = Vector3.Distance(nearestHidingSpot.position, thiefPos);

        for (int i = 1; i < safePoints.Length; i++)
        {
            if (Vector3.Distance(safePoints[i].position, thiefPos) < distanceToNearestHidingSpot)
            {
                nearestHidingSpot = safePoints[i];
                distanceToNearestHidingSpot = Vector3.Distance(nearestHidingSpot.position, thiefPos);
            }
        }

        return nearestHidingSpot;
    }

    public Transform[] GetPatrolRute(int numPatrol)
    {
        Transform[] patrolReturn = new Transform[numPatrol];
        for (int i = 0; i < patrolReturn.Length; i++)
        {
            patrolReturn[i] = character[Random.Range(0, character.Length)];
            numPatrolPointsAssigned++;


            for (int j = 0; j < i; j++)
            {
                if (patrolReturn[i] == patrolReturn[j])
                {
                    i--;
                    numPatrolPointsAssigned--;
                }
            }
        }

        return patrolReturn;
    }
    #endregion
}
