using UnityEngine;
using UnityEngine.AI;

public class WorkerPosingBehavior : StateMachineBehaviour
{
    NavMeshAgent _workerAgent;
    WorkerMovement _workerMovement;

     //OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _workerMovement = animator.gameObject.GetComponent<WorkerMovement>();
        _workerAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        if (_workerMovement.points == null)
        {
            _workerMovement.points = AIDirector.Instance.GetPatrolRute(6);
        }
        _workerMovement.GoToNextPoint();
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (!_workerAgent.pathPending && _workerAgent.remainingDistance < 0.5f)     //Comprueba si ha llegado al punto de posing? (vamos, que no curran) y va al siguiente (a por un caf� o algo)
        {
            if (_workerMovement.destPoint == _workerMovement.points.Length - 1)
            {   
                _workerMovement.points = AIDirector.Instance.GetPatrolRute(6);
                _workerMovement.destPoint = 0;
            }
            else
            {
                _workerMovement.destPoint++;
            }

            _workerMovement.GoToNextPoint();
        }  
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
