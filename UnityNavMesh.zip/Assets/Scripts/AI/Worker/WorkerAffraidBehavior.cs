using UnityEngine;

public class WorkerAffraidBehavior : StateMachineBehaviour
{
    WorkerMovement workerMovement;
    bool isAlarmActivated;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        workerMovement = animator.gameObject.GetComponent<WorkerMovement>();
        isAlarmActivated = AIDirector.Instance.alarmTriggered;
    }

     //OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (workerMovement.LookForGuard())      //Comprueba si hay un guardia cerca para volver a trabajar (o hacer como si)
        {
            animator.SetTrigger("Posing");
        }

        if (isAlarmActivated && !AIDirector.Instance.alarmTriggered)        //Si cuando ha entrado a este estado la alarma estaba encendida y se ha apagado, puede volver a trabajar.
        {
            animator.SetTrigger("Posing");
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
