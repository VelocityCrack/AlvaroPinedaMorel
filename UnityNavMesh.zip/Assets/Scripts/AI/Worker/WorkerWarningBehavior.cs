using UnityEngine;
using UnityEngine.AI;

public class WorkerWarningBehavior : StateMachineBehaviour
{
    NavMeshAgent _workerAgent;
    WorkerMovement _workerMovement;

    //OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _workerMovement = animator.gameObject.GetComponent<WorkerMovement>();
        _workerAgent = animator.gameObject.GetComponent<NavMeshAgent>();
        _workerMovement.GoToAlarm();
    }

    //OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (!_workerAgent.pathPending && _workerAgent.remainingDistance < 0.5f)     //Comprueba si ha llegado al punto de alarma
        {
            animator.SetTrigger("Alarm");
        }
    }

     //OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
