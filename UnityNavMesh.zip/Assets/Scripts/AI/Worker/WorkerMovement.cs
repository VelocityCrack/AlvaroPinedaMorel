using System;
using TreeEditor;
using UnityEngine;
using UnityEngine.AI;
using Random = UnityEngine.Random;

public class WorkerMovement : Movement
{
    Collider[] _colliders = new Collider[32];        //Cambiar puntos de patrulla al IA Director
    Animator _animator;
    Vector3 thiefSpotedPos;

    protected override void Start()
    {
        base.Start();
        _animator = GetComponent<Animator>();
    }

    private void OnEnable()
    {
        AIDirector.Instance.AlarmDetectionEventHandler += AlarmActivated;
    }

    private void OnDisable()
    {
        AIDirector.Instance.AlarmDetectionEventHandler -= AlarmActivated;
    }

    protected override void Update() 
    {
        base.Update();

        if (LookForThief() && !_animator.GetCurrentAnimatorStateInfo(0).IsName("Warning"))     //Compureba si ve al ladr�n
        {
            _animator.SetTrigger("Warning");
            AIDirector.Instance.ThiefSpoted(thiefSpotedPos);
        }
    }

    public bool LookForThief()      //Comprueba si ve al ladr�n
    {
        RaycastHit hit;

        Debug.DrawRay(_realPosition, 5 * transform.forward, Color.red);

        if (Physics.Raycast(_realPosition, 5 * transform.forward, out hit))
        {
            if (hit.collider.GetComponent<ThiefMovement>() != null)
            {
                thiefSpotedPos = hit.collider.GetComponent<ThiefMovement>()._realPosition;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public bool LookForGuard()      //Comprueba si el guardia est� cerca para irse del punto de agrupamiento a (no) trabajar
    {
        int counter = 0;

        Array.Clear(_colliders, 0, _colliders.Length);

        Physics.OverlapSphereNonAlloc(_realPosition, 5, _colliders);

        foreach (Collider collider in _colliders)
        {
            if (collider != null)
            {
                if (collider.GetComponent<GuardMovement>() != null)
                {
                    counter++;
                }
            }
        }

        if (counter != 0)
        {
            return true;
        }
        else 
        {
            return false;
        }
    }

    public void GoToAlarm()
    {
        GoToPosition(AIDirector.Instance.GetClosestAlarmPoint(_realPosition).position);
    }

    public void TriggerAlarm()
    {
        AIDirector.Instance.AlarmDetectionEventHandler?.Invoke();
    }

    private void AlarmActivated()
    {
        if (!_animator.GetCurrentAnimatorStateInfo(0).IsName("Alarm"))
        {
            _animator.SetTrigger("Alarm");
        }
    }
}

