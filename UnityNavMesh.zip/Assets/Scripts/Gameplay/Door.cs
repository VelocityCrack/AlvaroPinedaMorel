using System.Collections;
using Unity.AI.Navigation;
using UnityEngine;

public class Door : MonoBehaviour
{
    [SerializeField]
    private bool Enabled = false;
    [SerializeField]
    public float DoorSpeed = 1f;
    public GameObject Link_GO;
    public float doorClosingTime = 3f;

    private Coroutine m_RotationRoutine = null;
    private Transform m_Actor;
    private bool m_Opened = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!Enabled || other.gameObject.GetComponent<GuardMovement>() != null)
        {
            return;
        }
        if (m_RotationRoutine != null)
        {
            StopCoroutine(m_RotationRoutine);
        }
        m_Actor = other.gameObject.transform;

        if (!m_Opened)
        {
            StopCoroutine(CloseDoorCoroutine());
            OpenDoor();
        } else
        {
            m_RotationRoutine = StartCoroutine(CloseDoorCoroutine());
        }
    }

    private void OpenDoor()
    {
        bool clockWise = ObjectIsBehindDoor();
        float targetAngle = clockWise ? 90f : 270f;
        transform.localEulerAngles = new Vector3(0f, targetAngle, 0f);
        m_Opened = !m_Opened;
    }

    private IEnumerator CloseDoorCoroutine()
    {
        m_Opened = !m_Opened;
        yield return new WaitForSeconds(doorClosingTime);
        float currentAngle = transform.localEulerAngles.y;
        bool clockWise = m_Opened ? ((currentAngle % 360) >= 270) : ObjectIsBehindDoor();
        float targetAngle = 0f;
        float difference = Mathf.Abs(Mathf.DeltaAngle(targetAngle, currentAngle));
        float step = (DoorSpeed / 90f) * Time.fixedDeltaTime;
        currentAngle = 0;

        while (difference - currentAngle > 0)
        {
            currentAngle += step;
            transform.Rotate(0f, clockWise ? step : -step, 0f, Space.Self);
            yield return new WaitForFixedUpdate();
        }

        transform.localEulerAngles = new Vector3(0f, targetAngle, 0f);
        //m_Opened = true ? Link_GO.GetComponent<NavMeshLink>().activated = false : Link_GO.GetComponent<NavMeshLink>().activated = true;
        
    }

    private bool ObjectIsBehindDoor()
    {
        Vector3 doorTransformDirection = transform.TransformDirection(Vector3.forward);
        Vector3 playerTransformDirection = m_Actor.position - transform.position;
        return Vector3.Dot(doorTransformDirection, playerTransformDirection) < 0;
    }
}
